package com.tiago.android.trashtrack.entity;

/**
 * Model ItemEntity extended from RealmObject,
 * this class allows to receive the info from the database (Realm)
 * **/

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ItemEntity extends RealmObject{

    @PrimaryKey
    private int id;
    private String title;
    private String desc;
    private Double lat;
    private Double lng;
    private String pathPhoto;
    private String friendlyDate;
    private Long seconds;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLng() {
        return lng;
    }

    public void setLng(Double lng) {
        this.lng = lng;
    }

    public String getPathPhoto() {
        return pathPhoto;
    }

    public void setPathPhoto(String pathPhoto) {
        this.pathPhoto = pathPhoto;
    }

    public Long getSeconds() {
        return seconds;
    }

    public void setSeconds(Long seconds) {
        this.seconds = seconds;
    }

    public String getFriendlyDate() {
        return friendlyDate;
    }

    public void setFriendlyDate(String friendlyDate) {
        this.friendlyDate = friendlyDate;
    }
}
