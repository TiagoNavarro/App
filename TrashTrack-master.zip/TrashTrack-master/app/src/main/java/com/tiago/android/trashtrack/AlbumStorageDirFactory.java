package com.tiago.android.trashtrack;

/**
 * Class just to get the Album path (location where the photos are saved)
 * **/

import java.io.File;

abstract class AlbumStorageDirFactory {
    public abstract File getAlbumStorageDir(String albumName);
}