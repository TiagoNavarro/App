package com.tiago.android.trashtrack.adapter;

/**
 * Adapter takes the data sent by the DashboardActivity in mData (List).
 * It takes the layout "layout_item" to duplicate and insert the info in the RecyclerView.
 * layout_item contents: title, description and date of each item (denuncia)
 * **/


import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.tiago.android.trashtrack.R;
import com.tiago.android.trashtrack.entity.ItemEntity;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder>
        implements View.OnClickListener {

    private List<ItemEntity> mData;
    private View.OnClickListener listener;

    public ItemAdapter(List<ItemEntity> myData) {
        this.mData = myData;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvTitle;
        public TextView tvDescription;
        public TextView tvTime;

        public ViewHolder(View v) {
            super(v);
            tvTitle = (TextView) v.findViewById(R.id.tv_title);
            tvDescription = (TextView) v.findViewById(R.id.tv_description);
            tvTime = (TextView) v.findViewById(R.id.tv_time);
        }
    }

    @Override
    public ItemAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_item, parent, false);
        view.setOnClickListener(this);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.tvTitle.setText(mData.get(position).getTitle());
        holder.tvDescription.setText(mData.get(position).getDesc());
        holder.tvTime.setText(mData.get(position).getFriendlyDate());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if (listener != null)
            listener.onClick(v);
    }
}