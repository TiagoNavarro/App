package com.tiago.android.trashtrack;

/**
 * Base AppCompatActivity that allows to share methods between Activities
 * (SplashActivity and DashboardActivity)
 * **/

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class BaseAppCompatActivity extends AppCompatActivity {

    protected static final String NAME_PREFERENCE = "com.alvardev.android.trashtrack.preferences";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    protected double getCurrentLat() {
        SharedPreferences preferencias = this.getSharedPreferences(NAME_PREFERENCE, MODE_PRIVATE);
        return Double.parseDouble(preferencias.getString("currentLat", "-12.111561"));
    }

    protected double getCurrentLng() {
        SharedPreferences preferences = this.getSharedPreferences(NAME_PREFERENCE, MODE_PRIVATE);
        return Double.parseDouble(preferences.getString("currentLng", "-77.002723"));
    }

    protected void saveLatLng(double lat, double lng) {
        SharedPreferences preferences = this.getSharedPreferences(NAME_PREFERENCE, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("currentLat", String.valueOf(lat));
        editor.putString("currentLng", String.valueOf(lng));
        editor.apply();
    }

    public int getNewId() {
        SharedPreferences preferences = this.getSharedPreferences(NAME_PREFERENCE, MODE_PRIVATE);
        return preferences.getInt("lastId", 0)+1;
    }

    public void saveLastId(int lastId) {
        SharedPreferences preferences = this.getSharedPreferences(NAME_PREFERENCE, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("lastId", lastId);
        editor.apply();
    }

    public  String getNameMonth(int month){
        switch (month){
            case 0: return "Ene";
            case 1: return "Feb";
            case 2: return "Mar";
            case 3: return "Apr";
            case 4: return "May";
            case 5: return "Jun";
            case 6: return "Jul";
            case 7: return "Ago";
            case 8: return "Set";
            case 9: return "Oct";
            case 10: return "Nov";
            case 11: return "Dic";
            default: return "--";
        }
    }

    public  String getStringNumber(int number){
        return number < 10 ? "0" + number : number+"";
    }

}
