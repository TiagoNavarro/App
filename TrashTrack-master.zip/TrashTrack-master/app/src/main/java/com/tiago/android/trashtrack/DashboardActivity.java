package com.tiago.android.trashtrack;

/**
 * DashboardActivity controls all the features in the app
 * -
 * **/

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.tiago.android.trashtrack.adapter.ItemAdapter;
import com.tiago.android.trashtrack.entity.ItemEntity;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmResults;


public class DashboardActivity extends BaseAppCompatActivity implements OnMapReadyCallback {

    private final static String TAG = "DashboardActivity";
    static final int REQUEST_IMAGE_CAPTURE = 1;
    private GoogleMap mMap;
    private String mCurrentPhotoPath;
    private AlbumStorageDirFactory mAlbumStorageDirFactory;
    private ItemAdapter mAdapter;
    private int posSelected;
    private boolean showing;
    private boolean fromEdit;

    private Realm realm; //For connection to the Database (Realm)
    private RealmResults<ItemEntity> items; //it will receive the info from the Realm
    private RealmChangeListener<Realm> realmListener = new RealmChangeListener<Realm>() {
        @Override
        public void onChange(Realm element) {
            mAdapter.notifyDataSetChanged();
            rvItems.setVisibility(items.size() > 0 ? View.VISIBLE : View.GONE);
            tvNoResults.setVisibility(items.size() > 0 ? View.GONE : View.VISIBLE);
        }
    };//When some info is saved/update/delete from Real, it will update the RecyclerView automatically

    private View mainContent;
    private ImageView ivTakePicture;
    private TextView tvNoResults;
    private RecyclerView rvItems;
    private Button btNewItem;
    private Button btDelete;
    private Button btSave;
    private Button btCancel;
    private Button btGoUpdate;
    private TextInputEditText tiTitle;
    private TextInputEditText tiDesc;
    private TextView tvTitle;
    private TextView tvDesc;
    private TextView tvDate;

    private LinearLayout llaInfo;
    private LinearLayout llaForm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        realm = Realm.getDefaultInstance(); //Getting connection to Realm
        realm.addChangeListener(realmListener);
        mAlbumStorageDirFactory = new BaseAlbumDirFactory();
        posSelected = -1;
        setMap();
        setComponents();
        setActions();
        getData();
        setRecyclerView();
    }

    /***********************************
     * Components for the Activity
     * ********************************/

    /** Get the components from the View (activity_dashboard) by id **/
    private void setComponents(){
        mainContent = findViewById(R.id.main_content);
        ivTakePicture = (ImageView) findViewById(R.id.iv_take_picture);
        tvNoResults = (TextView) findViewById(R.id.tv_no_results);
        rvItems = (RecyclerView) findViewById(R.id.rv_items);
        btNewItem = (Button) findViewById(R.id.bt_new_item);
        btDelete = (Button) findViewById(R.id.bt_delete);
        btSave = (Button) findViewById(R.id.bt_save);
        btCancel = (Button) findViewById(R.id.bt_cancel);
        btGoUpdate = (Button) findViewById(R.id.bt_go_update);
        tiTitle = (TextInputEditText) findViewById(R.id.ti_title);
        tiDesc = (TextInputEditText) findViewById(R.id.ti_desc);
        tvTitle = (TextView) findViewById(R.id.tv_title);
        tvDesc = (TextView) findViewById(R.id.tv_desc);
        tvDate = (TextView) findViewById(R.id.tv_date);

        llaInfo = (LinearLayout) findViewById(R.id.lla_info);
        llaForm = (LinearLayout) findViewById(R.id.lla_form);
    }

    /** Set the Actions Listener for each Button **/
    private void setActions(){
        ivTakePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!showing){
                    dispatchTakePictureIntent(REQUEST_IMAGE_CAPTURE);
                }

            }
        });

        btNewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llaInfo.setVisibility(View.GONE);
                llaForm.setVisibility(View.VISIBLE);
                cleanAll();
            }
        });

        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = tiTitle.getText().toString();
                String desc = tiDesc.getText().toString();

                if(validateForm(title, desc)){
                    if(fromEdit && posSelected!=-1){
                        updatedItem(posSelected, title, desc);
                    }else{
                        saveItem(title, desc);
                    }
                }
            }
        });

        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llaInfo.setVisibility(View.VISIBLE);
                llaForm.setVisibility(View.GONE);
                showing = true;
            }
        });

        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(posSelected != -1){
                    AlertDialog.Builder builder = new AlertDialog.Builder(DashboardActivity.this);
                    builder.setPositiveButton(R.string.s_yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            deleteItem(posSelected);
                        }
                    });
                    builder.setNegativeButton(R.string.s_not, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                        }
                    });

                    builder.setTitle(getString(R.string.app_name));
                    builder.setMessage(getString(R.string.s_dialog_message));
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

        btGoUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(posSelected!=-1){
                    setDataForEdit(posSelected);
                }
            }
        });
    }

    /** Validate that que field are not empty when the user save/update an item **/
    private boolean validateForm(String title, String desc){
        tiTitle.setError(title.isEmpty() ? getString(R.string.s_no_title) : null);
        tiDesc.setError(desc.isEmpty() ? getString(R.string.s_no_desc) : null);
        if(mCurrentPhotoPath == null){
            showSnack(getString(R.string.s_no_picture));
        }
        return !(title.isEmpty() || desc.isEmpty() || mCurrentPhotoPath == null);
    }

    /***********************************
     * Queries
     * ********************************/

    /**  Save an Item in Realm **/
    private void saveItem(String title, String desc){
        Calendar  calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        String friendlyDate = getStringNumber(day)+"/"+ getNameMonth(month)+"/"+year;
        realm.beginTransaction();

        ItemEntity item = new ItemEntity();
        item.setId(getNewId());
        item.setTitle(title);
        item.setDesc(desc);
        item.setLat(getCurrentLat());
        item.setLng(getCurrentLng());
        item.setPathPhoto(mCurrentPhotoPath);
        item.setSeconds(calendar.getTimeInMillis());
        item.setFriendlyDate(friendlyDate);

        realm.copyToRealm(item);
        realm.commitTransaction();
        saveLastId(item.getId());
        cleanAll();
    }

    /** Update an Item on Realm **/
    private void updatedItem(int posSelectedLocal, String title, String desc){
        realm.beginTransaction();
        ItemEntity item = items.get(posSelectedLocal);
        item.setTitle(title);
        item.setDesc(desc);
        if(mCurrentPhotoPath != null){
            item.setPathPhoto(mCurrentPhotoPath);
        }
        realm.copyToRealmOrUpdate(item);
        realm.commitTransaction();
        cleanAll();
        llaInfo.setVisibility(View.VISIBLE);
        llaForm.setVisibility(View.GONE);
        showing = true;
        setDataById(item);

    }

    /**
     * Delete an item on Realm
     * **/
    private void deleteItem(final int posSelectedLocal){
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                items.get(posSelectedLocal).deleteFromRealm();
            }
        });

        cleanAll();
        llaInfo.setVisibility(View.GONE);
        llaForm.setVisibility(View.VISIBLE);
        this.posSelected = -1;
    }

    /**
     * Get all the items from Realm and order by seconds.
     * seconds are the timestamp when the user save an item,
     * this allows order the items from most recently to oldest
     * **/
    private void getData(){
        items = realm.where(ItemEntity.class).findAll();
        items = items.sort("seconds");
    }

    /***********************************
     * RecyclerView
     * ********************************/

    /**
     * RecyclerView takes the adapter and set the info from Realm.
     * When an item from the RecyclerView is clicked, it sets the info
     * from the item to the fields in the view.
     * When there's not items, the RecyclerView is hidden and appears a TextView with
     * a message
     * **/
    private void setRecyclerView(){
        rvItems.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(DashboardActivity.this);
        rvItems.setLayoutManager(mLayoutManager);

        mAdapter = new ItemAdapter(items);
        mAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posSelected = rvItems.getChildLayoutPosition(view);
                setDataById(items.get(posSelected));

            }
        });

        rvItems.setAdapter(mAdapter);
        rvItems.setItemAnimator(new DefaultItemAnimator());
        rvItems.setVisibility(items.size() > 0 ? View.VISIBLE : View.GONE);
        tvNoResults.setVisibility(items.size() > 0 ? View.GONE : View.VISIBLE);
    }

    /**
     * Set the info from an item selected in the RecyclerView
     * to the field in the view
     * **/
    private void setDataById(ItemEntity item){
        cleanAll();
        llaInfo.setVisibility(View.VISIBLE);
        showing = true;
        llaForm.setVisibility(View.GONE);

        tvTitle.setText(item.getTitle());
        tvDesc.setText(item.getDesc());
        tvDate.setText(item.getFriendlyDate());
        if(item.getPathPhoto() != null){
            File file = new File(item.getPathPhoto());
            if(file.exists()){
                setPic(file.getPath());
            }else{
                Log.i(TAG, "File does not exist");
            }
        }else{
            Log.i(TAG, "path is null");
        }
    }

    /**
     * When the user clicks 'Update' the fields are populated
     * with the info from the item selected
     * **/
    private void setDataForEdit(int posSelectedLocal){
        showing = false;
        llaInfo.setVisibility(View.GONE);
        llaForm.setVisibility(View.VISIBLE);
        tiTitle.setText(items.get(posSelectedLocal).getTitle());
        tiDesc.setText(items.get(posSelectedLocal).getDesc());
        mCurrentPhotoPath = items.get(posSelectedLocal).getPathPhoto();
        fromEdit = true;
    }

    /**
     * Clean all the field for a new Item to be saved
     * **/
    private void cleanAll(){
        ivTakePicture.setImageResource(R.drawable.img_camera);
        tiTitle.setText(null);
        tiDesc.setText(null);
        tvTitle.setText(getString(R.string.app_name));
        tvDesc.setText(getString(R.string.app_name));
        tvDate.setText(null);
        mCurrentPhotoPath = null;
        showing = false;
        fromEdit = false;
        double lat = getCurrentLat();
        double lng = getCurrentLng();
        setLocationInMap(lat, lng);
    }

    /** Shows a message in the bottom of the screen **/
    private void showSnack(String message){
        Snackbar.make(mainContent, message, Snackbar.LENGTH_LONG)
                .setAction("", null)
                .show();
    }

    /***********************************
     * Take a Picture
     * ********************************/

    /**
     * Capture photo from Camera
     **/
    private void dispatchTakePictureIntent(int actionCode) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File f;
        try {
            f = setUpPhotoFile();
            mCurrentPhotoPath = f.getAbsolutePath();
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
        } catch (IOException e) {
            e.printStackTrace();
            mCurrentPhotoPath = null;
        }

        startActivityForResult(takePictureIntent, actionCode);
    }

    private File setUpPhotoFile() throws IOException {
        File f = createImageFile();
        mCurrentPhotoPath = f.getAbsolutePath();
        return f;
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        return File.createTempFile(imageFileName, ".jpg", getAlbumDir());
    }

    private File getAlbumDir() {
        File storageDir = null;
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            storageDir = mAlbumStorageDirFactory.getAlbumStorageDir(getAlbumName());
            if (storageDir != null) {
                if (!storageDir.mkdirs()) {
                    if (!storageDir.exists()) {
                        Log.d("CameraSample", "failed to create directory");
                        return null;
                    }
                }
            }

        } else {
            Log.v(getString(R.string.app_name), "External storage is not mounted READ/WRITE.");
        }
        return storageDir;
    }

    /** Photo album for this application **/
    private String getAlbumName() {
        return getString(R.string.album_name);
    }

    /** it receives the photo after it has been taken from the camera**/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQUEST_IMAGE_CAPTURE:
                    handleBigCameraPhoto();
                    break;
            }
        }
    }

    /** validate that the photo exists in memory and send the photos path **/
    private void handleBigCameraPhoto() {
        if (mCurrentPhotoPath != null) {
            setPic(mCurrentPhotoPath);
            galleryAddPic();
        }
    }

    /** set the photo in the View **/
    private void setPic(String path) {
        /** There isn't enough memory to open up more than a couple camera photos **/
        /** So pre-scale the target bitmap into which the file is decoded **/

		/** Get the size of the ImageView **/
        int targetW = ivTakePicture.getWidth();
        int targetH = ivTakePicture.getHeight();

		/** Get the size of the image **/
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

		/** Figure out which way needs to be reduced less **/
        int scaleFactor = 1;
        if ((targetW > 0) || (targetH > 0)) {
            scaleFactor = Math.min(photoW / targetW, photoH / targetH);
        }

		/** Set bitmap options to scale the image decode target **/
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

		/** Decode the JPEG file into a Bitmap **/
        Bitmap bitmap = BitmapFactory.decodeFile(path, bmOptions);

        /** Associate the Bitmap to the ImageView **/
        ivTakePicture.setImageBitmap(bitmap);
    }

    /** Add the photo to the gallery **/
    private void galleryAddPic() {
        Intent mediaScanIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        File f = new File(mCurrentPhotoPath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }


    /***********************************
     * Google Maps
     * ********************************/

    /** set the map from the View**/
    private void setMap() {
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * After Google Maps is ready, get the latitude and longitude of the device
     * The latitude and the longitude were taken in SplashActivity
     * **/
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        double lat = getCurrentLat();
        double lng = getCurrentLng();

        setLocationInMap(lat, lng);
    }

    /** show the device location in the Google Map **/
    private void setLocationInMap(Double lat, Double lng){
        LatLng here = new LatLng(lat, lng);
        mMap.addMarker(new MarkerOptions().position(here).title("Você está aqui"));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(here.latitude, here.longitude))      // Sets the center of the map to Mountain View
                .zoom(16)                   // Sets the zoom
                .tilt(45)                   // Sets the tilt of the camera to 30 degrees
                .build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }

    /** When the activity is closed, the connection to Realm is closed too **/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        realm.close();
    }







}
